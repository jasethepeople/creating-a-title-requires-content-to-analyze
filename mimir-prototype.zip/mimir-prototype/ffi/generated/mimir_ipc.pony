// mimir_ipc.pony
// Auto-generated Pony bindings for Mimir FFI

use "lib:mimir_ipc"

struct MimirEvent
  var timestamp: U64 = 0
  var event_type: U32 = 0
  var payload_length: U32 = 0
  // In Pony, fixed arrays for FFI are tricky; using a pointer to the payload buffer
  var payload_ptr: Pointer[U8] = Pointer[U8]

primitive MimirFFI
  fun @init_shared_memory(shm_name: Pointer[U8] tag)
  fun @push_event(event: NullablePointer[MimirEvent]): Bool
  fun @pop_event(event: NullablePointer[MimirEvent]): Bool