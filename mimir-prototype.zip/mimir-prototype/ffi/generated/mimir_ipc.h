// mimir_ipc.h
// Auto-generated C-ABI definitions for Mimir Shared Memory IPC
#ifndef MIMIR_IPC_H
#define MIMIR_IPC_H

#include <stdint.h>
#include <stdbool.h>

// Shared Memory Ring Buffer Header
typedef struct {
    uint32_t head;
    uint32_t tail;
    uint32_t capacity;
    uint32_t element_size;
    bool is_locked;
} RingBufferHeader;

// A generic Mimir Event Payload
typedef struct {
    uint64_t timestamp;
    uint32_t event_type;
    uint32_t payload_length;
    uint8_t payload[256]; // Fixed size for zero-allocation fast path
} MimirEvent;

// FFI Function Exports
extern void init_shared_memory(const char* shm_name);
extern bool push_event(MimirEvent* event);
extern bool pop_event(MimirEvent* event);

#endif // MIMIR_IPC_H