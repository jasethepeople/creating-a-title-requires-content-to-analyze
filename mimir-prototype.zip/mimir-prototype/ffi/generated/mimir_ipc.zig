// mimir_ipc.zig
// Auto-generated Zig bindings for Mimir FFI
const std = @import("std");

pub const RingBufferHeader = extern struct {
    head: u32,
    tail: u32,
    capacity: u32,
    element_size: u32,
    is_locked: bool,
};

pub const MimirEvent = extern struct {
    timestamp: u64,
    event_type: u32,
    payload_length: u32,
    payload: [256]u8,
};

extern "c" fn init_shared_memory(shm_name: [*:0]const u8) void;
extern "c" fn push_event(event: *MimirEvent) bool;
extern "c" fn pop_event(event: *MimirEvent) bool;

pub fn init(name: [:0]const u8) void {
    init_shared_memory(name.ptr);
}